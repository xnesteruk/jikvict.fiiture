# Hello World

### Uloha

Implement a simple Hello World program.

#### Task 1 — `sayHello(String name)`

Implement the method `sayHello` in the `HelloWorld` class.

The method should return a greeting string in the following format:

```
Hello, <name>!
```

For example, `sayHello("Alice")` should return `"Hello, Alice!"`.

#### Task 2 — `sayHelloMultiple(String[] names)`

Implement the method `sayHelloMultiple` in the `HelloWorld` class.

The method should return a single string that greets each person on a separate line.

For example, `sayHelloMultiple(new String[]{"Alice", "Bob"})` should return:
```
Hello, Alice!
Hello, Bob!
```

> **Note:** There should be no trailing newline at the end.

#### Task 3 — `countGreetings(String[] names)`

Implement the method `countGreetings` in the `HelloWorld` class.

The method should return the number of names in the given array.
