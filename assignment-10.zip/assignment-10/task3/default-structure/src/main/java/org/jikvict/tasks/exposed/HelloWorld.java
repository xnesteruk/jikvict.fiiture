package org.jikvict.tasks.exposed;

public class HelloWorld {

    public static void main(String[] args) {

        System.out.println(sayHello("World"));
        String[] names = {"Alice", "Bob"};
        System.out.println(sayHelloMultiple(names));

        String[] mena = {"Alice", "Bob", "Charlie"};
        System.out.println(sayHelloMultiple(mena));
        System.out.println(countGreetings(mena));


    }

    public static String sayHello(String name) {
        return "Hello, " + name + "!";
    }

    public static String sayHelloMultiple(String[] names) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < names.length; i++) {
            result.append(sayHello(names[i]));
            if (i < names.length - 1) {
                result.append("\n");
            }
        }
        return result.toString();
    }

    public static int countGreetings(String[] names) {
        return names.length;
    }
}