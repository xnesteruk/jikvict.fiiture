package org.jikvict.tasks.exposed;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class GameWorld {

    private static GameWorld instance;

    private List<GameCharacter> party;
    private CombatEventManager eventManager;

    private GameWorld() {
        party = new ArrayList<>();
        eventManager = new CombatEventManager();
    }

    public static GameWorld getInstance() {
        if (instance == null) {
            instance = new GameWorld();
        }
        return instance;
    }

    public static void resetInstance() {
        instance = null;
    }

    public void addCharacter(GameCharacter character) {
        party.add(character);
    }

    public void removeCharacter(String name) {
        party.removeIf(c -> c.getName().equals(name));
    }

    public GameCharacter findCharacter(String name) {
        for (GameCharacter c : party) {
            if (c.getName().equals(name)) return c;
        }
        return null;
    }

    public List<GameCharacter> getParty() {
        return Collections.unmodifiableList(party);
    }

    public CombatEventManager getEventManager() {
        return eventManager;
    }
}