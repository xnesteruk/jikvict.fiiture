rootProject.name = "default-structure"
