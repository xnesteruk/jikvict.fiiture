package org.jikvict.tasks.exposed;

/**
 * Warrior character: high armor, balanced damage.
 * Extends GameCharacter.
 */
public class Warrior extends GameCharacter {

    private int armorRating;

    /**
     * Creates a new Warrior.
     *
     * @param name            the warrior's name
     * @param health          starting health
     * @param baseAttackPower base attack power
     * @param armorRating     armor protection level
     */
    public Warrior(String name, int health, int baseAttackPower, int armorRating) {
        super(name, health, baseAttackPower);
        this.armorRating = armorRating;
    }

    @Override
    public String getCharacterType() {
        return "Warrior";
    }

    /**
     * Damage formula: baseAttackPower + armorRating / 2 (integer division)
     */
    @Override
    public int calculateDamage() {
        return baseAttackPower + (armorRating / 2);
    }

    /**
     * Takes damage but reduces it by armor absorption.
     * Effective damage = Math.max(0, damage - armorRating / 3)
     */
    @Override
    public void takeDamage(int damage) {
        int reducedDamage = Math.max(0, damage - (armorRating / 3));
        super.takeDamage(reducedDamage);
    }

    /**
     * Returns info with armor added.
     */
    @Override
    public String getInfo() {
        return super.getInfo() + " | Armor: " + armorRating;
    }

    public int getArmorRating() {
        return armorRating;
    }

    public void setArmorRating(int armorRating) {
        this.armorRating = armorRating;
    }
}