package org.jikvict.tasks.exposed;

/**
 * Archer character: ranged attacker with limited arrows.
 * Extends GameCharacter.
 */
public class Archer extends GameCharacter {

    private int arrowCount;

    /**
     * Creates a new Archer.
     *
     * @param name            the archer's name
     * @param health          starting health
     * @param baseAttackPower base attack power
     * @param arrowCount      number of arrows
     */
    public Archer(String name, int health, int baseAttackPower, int arrowCount) {
        super(name, health, baseAttackPower);
        this.arrowCount = arrowCount;
    }

    @Override
    public String getCharacterType() {
        return "Archer";
    }

    /**
     * Damage formula: baseAttackPower + 5
     */
    @Override
    public int calculateDamage() {
        return baseAttackPower + 5;
    }

    /**
     * Returns info with arrows added.
     */
    @Override
    public String getInfo() {
        return super.getInfo() + " | Arrows: " + arrowCount;
    }

    /**
     * Shoots an arrow, decreasing arrow count.
     *
     * @return true if arrow was shot (had arrows), false otherwise
     */
    public boolean shootArrow() {
        if (arrowCount > 0) {
            arrowCount--;
            return true;
        }
        return false;
    }

    public int getArrowCount() {
        return arrowCount;
    }

    public void setArrowCount(int arrowCount) {
        this.arrowCount = arrowCount;
    }
}