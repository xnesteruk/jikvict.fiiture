package org.jikvict.tasks.exposed;

/**
 * Mage character: low health, high damage, uses mana for spells.
 * Extends GameCharacter.
 */
public class Mage extends GameCharacter {

    private int mana;
    private int maxMana;

    /**
     * Creates a new Mage.
     *
     * @param name            the mage's name
     * @param health          starting health
     * @param baseAttackPower base attack power
     * @param mana            starting (and maximum) mana
     */
    public Mage(String name, int health, int baseAttackPower, int mana) {
        super(name, health, baseAttackPower);
        this.mana = mana;
        this.maxMana = mana;
    }

    @Override
    public String getCharacterType() {
        return "Mage";
    }

    /**
     * Damage formula: baseAttackPower * 2
     */
    @Override
    public int calculateDamage() {
        return baseAttackPower * 2;
    }

    /**
     * Returns info with mana added.
     */
    @Override
    public String getInfo() {
        return super.getInfo() + " | Mana: " + mana + "/" + maxMana;
    }

    /**
     * Casts a spell (method overload 1: no arguments).
     * Costs 10 mana.
     *
     * @return message about casting a spell
     */
    public String castSpell() {
        if (mana < 10) {
            return getName() + " does not have enough mana!";
        }
        mana -= 10;
        return getName() + " casts a spell!";
    }

    /**
     * Casts a named spell (method overload 2: spell name).
     * Costs 10 mana.
     *
     * @param spellName the name of the spell
     * @return message about casting the spell
     */
    public String castSpell(String spellName) {
        if (mana < 10) {
            return getName() + " does not have enough mana!";
        }
        mana -= 10;
        return getName() + " casts " + spellName + "!";
    }

    /**
     * Casts a spell on a target (method overload 3: spell name + target).
     * Costs 10 mana and deals damage to target.
     *
     * @param spellName the name of the spell
     * @param target    the target character
     * @return message about casting the spell on the target
     */
    public String castSpell(String spellName, GameCharacter target) {
        if (mana < 10) {
            return getName() + " does not have enough mana!";
        }
        mana -= 10;
        target.takeDamage(calculateDamage());
        return getName() + " casts " + spellName + " on " + target.getName() + "!";
    }

    public int getMana() {
        return mana;
    }

    public int getMaxMana() {
        return maxMana;
    }

    public void setMana(int mana) {
        this.mana = mana;
    }
}