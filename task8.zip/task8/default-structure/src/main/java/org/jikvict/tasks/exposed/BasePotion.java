package org.jikvict.tasks.exposed;

public class BasePotion implements Potion {

    private final String name;
    private final String description;
    private final int healingPower;
    private final int duration;

    public BasePotion(String name, String description, int healingPower, int duration)
            throws InvalidPotionException {
        if (healingPower < 0) {
            throw new InvalidPotionException(
                    "Healing power cannot be negative, got: " + healingPower);
        }
        if (duration <= 0) {
            throw new InvalidPotionException(
                    "Duration must be positive, got: " + duration);
        }
        this.name = name;
        this.description = description;
        this.healingPower = healingPower;
        this.duration = duration;
    }

    @Override public String getName()        { return name; }
    @Override public String getDescription() { return description; }
    @Override public int getHealingPower()   { return healingPower; }
    @Override public int getDuration()       { return duration; }

    @Override
    public void apply(GameCharacter target) throws GameException {
        if (!target.isAlive()) {
            throw new CharacterDeadException(
                    "Cannot apply potion to a dead character: " + target.getName());
        }
        target.heal(healingPower);
    }
}