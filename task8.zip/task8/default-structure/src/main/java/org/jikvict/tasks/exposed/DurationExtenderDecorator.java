package org.jikvict.tasks.exposed;

public class DurationExtenderDecorator extends PotionDecorator {

    private final int multiplier;

    public DurationExtenderDecorator(Potion wrapped, int multiplier) {
        super(wrapped);
        this.multiplier = multiplier;
    }

    @Override
    public int getDuration() {
        return wrapped.getDuration() * multiplier;
    }

    @Override
    public String getDescription() {
        return wrapped.getDescription() + ", Duration x" + multiplier;
    }

    // apply() delegates entirely to wrapped — duration is metadata only
}