package org.jikvict.tasks.exposed;

public abstract class PotionDecorator implements Potion {

    protected final Potion wrapped;

    public PotionDecorator(Potion wrapped) {
        this.wrapped = wrapped;
    }

    @Override public String getName()        { return wrapped.getName(); }
    @Override public String getDescription() { return wrapped.getDescription(); }
    @Override public int getHealingPower()   { return wrapped.getHealingPower(); }
    @Override public int getDuration()       { return wrapped.getDuration(); }

    @Override
    public void apply(GameCharacter target) throws GameException {
        wrapped.apply(target);
    }
}