package org.jikvict.tasks.exposed;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;

public class Inventory<T> {

    private final int capacity;
    private final List<T> items;

    public Inventory(int capacity) {
        this.capacity = capacity;
        this.items = new ArrayList<>();
    }

    /** Adds an item; throws {@link InventoryFullException} if at capacity. */
    public void add(T item) throws InventoryFullException {
        if (isFull()) {
            throw new InventoryFullException(
                    "Inventory is full (capacity: " + capacity + ")");
        }
        items.add(item);
    }

    /** Removes the item; returns {@code true} if it was present. */
    public boolean remove(T item) {
        return items.remove(item);
    }

    /** Returns {@code true} if the inventory contains the item. */
    public boolean contains(T item) {
        return items.contains(item);
    }

    public int size()       { return items.size(); }
    public boolean isFull() { return items.size() >= capacity; }
    public boolean isEmpty(){ return items.isEmpty(); }
    public int getCapacity(){ return capacity; }

    /** Returns an unmodifiable view of all items. */
    public List<T> getItems() {
        return Collections.unmodifiableList(items);
    }

    // ── functional methods ────────────────────────────────────────────────────

    /** Returns all items that satisfy the filter. */
    public List<T> findAll(ItemFilter<T> filter) {
        List<T> result = new ArrayList<>();
        for (T item : items) {
            if (filter.test(item)) result.add(item);
        }
        return result;
    }

    /** Returns the first item that satisfies the filter, or empty. */
    public Optional<T> findFirst(ItemFilter<T> filter) {
        for (T item : items) {
            if (filter.test(item)) return Optional.of(item);
        }
        return Optional.empty();
    }

    /** Executes the action on every item in the inventory. */
    public void applyToAll(Consumer<T> action) {
        for (T item : items) {
            action.accept(item);
        }
    }
}