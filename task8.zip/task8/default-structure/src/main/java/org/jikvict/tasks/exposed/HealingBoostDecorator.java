package org.jikvict.tasks.exposed;

public class HealingBoostDecorator extends PotionDecorator {

    private final int bonus;

    public HealingBoostDecorator(Potion wrapped, int bonus) {
        super(wrapped);
        this.bonus = bonus;
    }

    @Override
    public int getHealingPower() {
        return wrapped.getHealingPower() + bonus;
    }

    @Override
    public String getDescription() {
        return wrapped.getDescription() + ", Healing Boost +" + bonus;
    }

    @Override
    public void apply(GameCharacter target) throws GameException {
        wrapped.apply(target);          // base healing (also handles dead-check)
        target.heal(bonus);             // additional bonus healing
    }
}