public class HelloWorld {
    public String sayHello(String name) {
        return "Hello, " + name + "!";
    }

    public String sayHelloMultiple(String[] names) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < names.length; i++) {
            sb.append(sayHello(names[i]));
            if (i < names.length - 1) {
                sb.append("\n");
            }
        }
        return sb.toString();
    }

    public int countGreetings(String[] names) {
        return names.length;
    }

}