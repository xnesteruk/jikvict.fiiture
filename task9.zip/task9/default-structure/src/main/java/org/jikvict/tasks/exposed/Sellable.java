package org.jikvict.tasks.exposed;

public interface Sellable {
    double getPrice();
    String getLabel();
}
 