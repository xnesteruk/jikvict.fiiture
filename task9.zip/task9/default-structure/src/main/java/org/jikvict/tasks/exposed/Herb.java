package org.jikvict.tasks.exposed;

public class Herb extends Plant implements Growable, Treatable, Sellable {

    static {
        System.out.println("[Herb] Static initializer block");
    }

    private final double maxHeight;
    private final double price;
    private double height = 0.0;
    private int health = 60;

    {
        System.out.println("[Herb] Instance initializer block");
    }

    public Herb(String name, double maxHeight, double price) {
        super(name, "Herb");
        this.maxHeight = maxHeight;
        this.price = price;
        System.out.println("[Herb] Constructor called for: " + name);
    }

    @Override
    public void grow() {
        if (!isFullyGrown()) {
            height = Math.min(height + 1.8, maxHeight);
        }
    }

    @Override
    public double getHeight() {
        return height;
    }

    @Override
    public boolean isFullyGrown() {
        return height >= maxHeight;
    }

    @Override
    public void water() {
        health = Math.min(health + 15, 100);
    }

    @Override
    public void fertilize() {
        if (!isFullyGrown()) {
            height = Math.min(height + 2.0, maxHeight);
        }
    }

    @Override
    public int getHealthLevel() {
        return health;
    }

    @Override
    public double getPrice() {
        return price;
    }

    @Override
    public String getLabel() {
        return getName() + " — Fresh herb, " + String.format("%.2f", price) + " €";
    }
}