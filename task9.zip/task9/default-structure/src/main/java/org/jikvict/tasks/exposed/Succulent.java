package org.jikvict.tasks.exposed;

public class Succulent extends Plant implements Growable {

    static {
        System.out.println("[Succulent] Static initializer block");
    }

    private final double maxHeight;
    private double height = 0.0;

    {
        System.out.println("[Succulent] Instance initializer block");
    }

    public Succulent(String name, double maxHeight) {
        super(name, "Succulent");
        this.maxHeight = maxHeight;
        System.out.println("[Succulent] Constructor called for: " + name);
    }

    @Override
    public void grow() {
        if (!isFullyGrown()) {
            height = Math.min(height + 0.5, maxHeight);
        }
    }

    @Override
    public double getHeight() {
        return height;
    }

    @Override
    public boolean isFullyGrown() {
        return height >= maxHeight;
    }
}