package org.jikvict.tasks.exposed;

public class Flower extends Plant implements Growable, Treatable {

    static {
        System.out.println("[Flower] Static initializer block");
    }

    private final double maxHeight;
    private double height = 0.0;
    private int health = 50;

    {
        System.out.println("[Flower] Instance initializer block");
    }

    public Flower(String name, double maxHeight) {
        super(name, "Flower");
        this.maxHeight = maxHeight;
        System.out.println("[Flower] Constructor called for: " + name);
    }

    @Override
    public void grow() {
        if (!isFullyGrown()) {
            height = Math.min(height + 2.5, maxHeight);
        }
    }

    @Override
    public double getHeight() {
        return height;
    }

    @Override
    public boolean isFullyGrown() {
        return height >= maxHeight;
    }

    @Override
    public void water() {
        health = Math.min(health + 10, 100);
    }

    @Override
    public void fertilize() {
        if (!isFullyGrown()) {
            height = Math.min(height + 1.5, maxHeight);
        }
    }

    @Override
    public int getHealthLevel() {
        return health;
    }
}